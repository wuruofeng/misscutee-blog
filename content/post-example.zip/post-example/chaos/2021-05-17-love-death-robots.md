--- 
title: 爱死机，爱发电
author: Elizen
date: 2021-05-17
tags: chaos
slug: love-death-robots
---

虽然，我还没看，就发现网上各种喷，豆瓣[评分](https://movie.douban.com/subject/34418203/)也落到 7 分上下，但是就算新一季再垃圾，也比大部分国产电影好吧？

而且，我还发现了一个小现象，豆瓣电影，7.5 分上下的作品，其实是最好看，看起来最舒服的。
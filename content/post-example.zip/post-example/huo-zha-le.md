---
title: 来一曲东北灭火朋克
date: 2020-04-09
tags: music
---

个人喜好，奔走相告。

我一直喜欢的东北灭火朋克历时十五年，终于发了[新专辑](https://music.163.com/#/album?id=87731914)了。

{{< music auto="https://music.163.com/#/song?id=1438432532" >}}
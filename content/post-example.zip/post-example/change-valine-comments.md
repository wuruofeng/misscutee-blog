---
title: "博客增加了 Valine 评论"
date: 2020-04-13
tags: blog
---


扒了木木哥的主题在研究，本来想弄一下文章内直接撸照片文件夹，试了半天没成功，反倒是随手把 Valine 评论给偷了过来，好用。

好像木木哥那里没有具体教程，可以去他的网站[搜一搜](https://immmmm.com/search/?q=valine)。

----

ChangeLog

更新了 Valine 评论邮件回复 2020-04-14 
---
title: Bob Dylan 新专辑《Rough and Rowdy Ways》
date: 2020-07-20
tags: music
---

就像过年一样，Bob Dylan 直到今天还能发一张如此高质量的[专辑](https://music.163.com/#/album?id=90811836)，不知道那些年轻人听了作何感想。

从这个角度看，碧梨确实很强。

{{< music auto="https://music.163.com/#/album?id=90811836" >}}